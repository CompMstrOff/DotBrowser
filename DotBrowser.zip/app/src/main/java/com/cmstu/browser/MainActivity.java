package com.cmstu.browser;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.cmstu.browser.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private MainBinding binding;
	
	private RequestNetwork connect;
	private RequestNetwork.RequestListener _connect_request_listener;
	private Intent options = new Intent();
	private Intent secret = new Intent();
	private Intent start = new Intent();
	private Intent setup = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		connect = new RequestNetwork(this);
		
		binding.webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				_setnetwork();
				binding.progressbar1.setVisibility(View.VISIBLE);
				binding.edittext1.setText(_url);
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				binding.progressbar1.setVisibility(View.GONE);
				binding.edittext1.setText(_url);
				super.onPageFinished(_param1, _param2);
			}
		});
		
		binding.circleimageview1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				startActivity(secret);
				return true;
			}
		});
		
		binding.circleimageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				///credit To @Davizyjacob/Don't edit or change any code here//
				{PopupMenu popup = new PopupMenu(MainActivity.this, binding.circleimageview1);
					android.view.Menu menu = popup.getMenu();
					
					///credit To @Davizyjacob/Don't edit or change any code here//
					menu.add("Back").setIcon(R.drawable.icon_arrow_back_round);
					///credit To @Davizyjacob/Don't edit or change any code here//
					///credit To @Davizyjacob/Don't edit or change any code here//
					menu.add("Forward").setIcon(R.drawable.icon_arrow_forward_round);
					///credit To @Davizyjacob/Don't edit or change any code here//
					///credit To @Davizyjacob/Don't edit or change any code here//
					menu.add("Home").setIcon(R.drawable.icon_home_round);
					///credit To @Davizyjacob/Don't edit or change any code here//
					///credit To @Davizyjacob/Don't edit or change any code here//
					menu.add("About").setIcon(R.drawable.icon_menu_round);
					///credit To @Davizyjacob/Don't edit or change any code here//
					///credit To @Davizyjacob/Don't edit or change any code here//
					menu.add("Developer").setIcon(R.drawable.icon_extension_round);
					///credit To @Davizyjacob/Don't edit or change any code here//
					///credit To @Davizyjacob/Don't edit or change any code here//
					try {
						java.lang.reflect.Field[] fields = popup.getClass().getDeclaredFields();
						for (java.lang.reflect.Field field : fields) {
							if ("mPopup".equals(field.getName())) {
								field.setAccessible(true);
								Object menuPopupHelper = field.get(popup); Class<?> classPopupHelper = Class.forName(menuPopupHelper.getClass().getName());
								java.lang.reflect.Method setForceIcons = classPopupHelper.getMethod("setForceShowIcon", boolean.class); setForceIcons.invoke(menuPopupHelper, true);
								break;
							}
						}
					} catch(Exception e) {
						e.printStackTrace();
					}
					///credit To @Davizyjacob/Don't edit or change any code here//
					///credit To @Davizyjacob/Don't edit or change any code here//
					popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
						
						public boolean onMenuItemClick(android.view.MenuItem item) {
							switch (item.getTitle().toString()) {
								
								///credit To @Davizyjacob/Don't edit or change any code here//
								case "Back":
								_backcheck();
								return true;
								///credit To @Davizyjacob/Don't edit or change any code here//
								///credit To @Davizyjacob/Don't edit or change any code here//
								case "Forward":
								_forwcheck();
								return true;
								///credit To @Davizyjacob/Don't edit or change any code here//
								///credit To @Davizyjacob/Don't edit or change any code here//
								case "Home":
								binding.edittext1.setText("file:///android_asset/start.html");
								binding.button1.performClick();
								return true;
								///credit To @Davizyjacob/Don't edit or change any code here//
								///credit To @Davizyjacob/Don't edit or change any code here//
								case "About":
								startActivity(options);
								return true;
								///credit To @Davizyjacob/Don't edit or change any code here//
								///credit To @Davizyjacob/Don't edit or change any code here//
								case "Developer":
								_dev();
								return true;
								///credit To @Davizyjacob/Don't edit or change any code here//
								
								default: return false;
							}
						}
					});
					///credit To @Davizyjacob/Don't edit or change any code here//
					
					popup.show();}
				///credit To @Davizyjacob/Don't edit or change any code here//
			}
		});
		
		binding.button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				binding.webview1.loadUrl(binding.edittext1.getText().toString());
			}
		});
		
		_connect_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		_setnetwork();
		binding.webview1.getSettings().setJavaScriptEnabled(true);
		
		binding.progressbar1.setVisibility(View.INVISIBLE);
		secret.setClass(getApplicationContext(), SecretActivity.class);
		options.setClass(getApplicationContext(), AboutActivity.class);
		binding.edittext1.setText("file:///android_asset/start.html");
		binding.webview1.loadUrl(binding.edittext1.getText().toString());
	}
	
	@Override
	public void onBackPressed() {
		if (binding.webview1.canGoBack()) {
			binding.webview1.goBack();
		} else {
			finishAffinity();
		}
	}
	public void _setnetwork() {
		if (!SketchwareUtil.isConnected(getApplicationContext())) {
			binding.circleimageview1.setImageResource(R.drawable.noint);
			SketchwareUtil.showMessage(getApplicationContext(), "No internet connection!");
			if (false) {
				binding.webview1.stopLoading();
			}
		} else {
			binding.circleimageview1.setImageResource(R.drawable.ulrescmstubrowsericon);
		}
	}
	
	
	public void _backcheck() {
		if (binding.webview1.canGoBack()) {
			binding.webview1.goBack();
		} else {
			SketchwareUtil.showMessage(getApplicationContext(), "Can't go back");
		}
	}
	
	
	public void _forwcheck() {
		if (binding.webview1.canGoForward()) {
			binding.webview1.goForward();
		} else {
			SketchwareUtil.showMessage(getApplicationContext(), "Can't go forward");
		}
	}
	
	
	public void _dev() {
		///credit To @Davizyjacob/Don't edit or change any code here//
		{PopupMenu popup = new PopupMenu(MainActivity.this, binding.circleimageview1);
			android.view.Menu menu = popup.getMenu();
			
			///credit To @Davizyjacob/Don't edit or change any code here//
			menu.add("JavaScript").setIcon(R.drawable.icon_javascript_round);
			///credit To @Davizyjacob/Don't edit or change any code here//
			///credit To @Davizyjacob/Don't edit or change any code here//
			popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
				
				public boolean onMenuItemClick(android.view.MenuItem item) {
					switch (item.getTitle().toString()) {
						
						///credit To @Davizyjacob/Don't edit or change any code here//
						case "JavaScript":
						binding.edittext1.setText("file:///android_asset/jstest.html");
						binding.button1.performClick();
						return true;
						///credit To @Davizyjacob/Don't edit or change any code here//
						
						default: return false;
					}
				}
			});
			///credit To @Davizyjacob/Don't edit or change any code here//
			
			popup.show();}
		///credit To @Davizyjacob/Don't edit or change any code here//
	}
	
}